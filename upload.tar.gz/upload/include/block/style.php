<?php
HTML::$style = 
<<<HEREDOC
* {
	font-family: Sans;
	font-size: 16px;
}
input {
	margin: 2px;
}
HEREDOC;
