<?php

class Main
{//{{{
	function __construct()
	{//{{{
		$request_method = array_get_string('REQUEST_METHOD', $_SERVER);
		if(!is_string($request_method)) {
			trigger_error("Can't get http request method", E_USER_WARNING);
			return(false);
		}
		
		switch($request_method) {
			case('GET'):
				$return = $this->handle_get_request();
				if($return !== true) {
					trigger_error("Handle get request failed", E_USER_ERROR);
					exit(255);
				}
				
				$HTML = new HTML;
				exit(0);
				
			case('POST'):
				$return = $this->handle_post_request();
				if($return !== true) {
					trigger_error("Handle post request failed", E_USER_ERROR);
					exit(255);
				}
				$HTML = new HTML;
				exit(0);
				
			default:
				if(defined('DEBUG') && DEBUG) var_dump(['$request_method' => $request_method]);
				trigger_error("Unsupported request method", E_USER_ERROR);
				exit(255);
		}
	}//}}}
	
	function handle_get_request()
	{//{{{
		$php_ini_loaded_file = php_ini_loaded_file();

		$post_max_size = ini_get('post_max_size');
		$upload_max_filesize = ini_get('upload_max_filesize');

		HTML::$body .= 
<<<HEREDOC
<h4>Upload files php parameters</h4>

php_ini_loaded_file = {$php_ini_loaded_file}</br>
post_max_size = {$post_max_size}<br />
upload_max_filesize = {$upload_max_filesize}
HEREDOC;	
		
		$csrf_input = HTML::generate_csrf_input();
		$url_path = HTML::get_url_path();
		HTML::$body .= 
			<<<HEREDOC
<hr />
<form action="{$url_path}" method="post" enctype="multipart/form-data">
	{$csrf_input}
	<label>
		file for upload<br />
		<input name="file" type="file" />
	</label><br />
	<label>
		path to upload<br />
		<input name="path" value="/home/user" size="48" />
	</label><br />
	<input value="upload" type="submit" />
</form>
HEREDOC;
		return(true);
	}//}}}
	
	function handle_post_request()
	{//{{{
		$file = array_get_array('file', $_FILES);
		if(!is_array($file)) {
			trigger_error("Incorrect array 'file' in '_FILES' array", E_USER_WARNING);
			return(false);
		}

		$error = array_get_int('error', $file);
		if(!is_int($error)) {
			trigger_error("Incorrect int 'error' in 'file' array", E_USER_WARNING);
			return(false);
		}
		if($error !== 0) {
			trigger_error("File uploading error", E_USER_WARNING);
			return(false);
		}

		$name = array_get_string('name', $file);
		if(!is_string($name)) {
			trigger_error("Incorrect string 'name' in 'file' array", E_USER_WARNING);
			return(false);
		}

		$tmp_name = array_get_string('tmp_name', $file);
		if(!is_string($tmp_name)) {
			trigger_error("Incorrect string 'tmp_name' in 'file' array", E_USER_WARNING);
			return(false);
		}

		$path = array_get_string('path', $_POST);
		if(!is_string($path)) {
			trigger_error("Incorrect string 'path' in '_POST' array", E_USER_WARNING);
			return(false);
		}
		$path = rtrim($path, '/');
		
		$return = is_uploaded_file($tmp_name);
		if(!$return) {
			trigger_error("tmp file is not uploaded", E_USER_WARNING);
			return(false);
		}
		
		$path = "{$path}/{$name}";
		$return = move_uploaded_file($tmp_name, $path);
		if(!$return) {
			trigger_error("Can't move upload file", E_USER_WARNING);
			return(false);
		}

		HTML::$body .=
<<<HEREDOC
<h4>file uploaded</h4>
{$path}
HEREDOC;
		return(true);
	}//}}}
	
}//}}}

