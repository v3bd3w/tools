<?php
set_include_path(__DIR__.'/include');
require_once('block/http_init.php');
require_once('function/array_get_type.php');
require_once('class/HTML.php');
require_once('class/Main.php');
require_once('block/style.php');

$Main = new Main();
