/// codercursor
var codercursor = { // {{{
	cursor: null,
	editor: null,
	init: function(editor)
	{
		this.editor = editor;
		this.cursor = document.querySelector("div[name='codercursor']");
		this.cursor.style.setProperty("border-bottom", "solid 2px white");
		setInterval(this.blink.bind(this), 500);
	},
	blink: function()
	{
		var border = this.cursor.style.getPropertyValue("border-bottom");
		if(border == "2px solid white") {
			this.cursor.style.setProperty("border-bottom", "solid 2px black");
		}
		else {
			this.cursor.style.setProperty("border-bottom", "solid 2px white");
		}
	},
	show: function()
	{
		var cursorCoords = this.editor.cursorCoords();
		this.cursor.style.setProperty("top", cursorCoords.top + "px");
		this.cursor.style.setProperty("left", cursorCoords.left + "px");
	},
}; // }}}


var coderbuttons = [];
window.addEventListener("load", function(event) { // {{{

	var i = 0;
	for(i = i; i < 80; i += 1) {
		var id = "CB-" + String(i);
		var coderbutton = document.getElementById(id);
		coderbuttons.push(coderbutton);
	}
} ); // }}}
