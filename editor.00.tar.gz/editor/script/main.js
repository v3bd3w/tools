function out($var){$var=JSON.stringify($var);alert($var);}

window.addEventListener("load", function(event) {
	editor.init();
	editor.textarea.setSelectionRange(18,28);

	cursor.init();
	var $location = editor.getLocation(23);
	out($location);
	cursor.to($location.column, $location.row);

} );

