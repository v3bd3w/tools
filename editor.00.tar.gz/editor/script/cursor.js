var cursor = {
	div: null,
	width: 10,
	height: 20,
	maxColumn: 52,
	maxRow: 4,
	init: function()
	{
		this.div = document.querySelector("div[name='cursor']");
		this.div.style.setProperty("border-bottom", "2px solid white");
		setInterval(this.blink.bind(this), 500);
	},
	blink: function()
	{
		var border = this.div.style.getPropertyValue("border-bottom");
		if(border == "2px solid white") {
			this.div.style.setProperty("border-bottom", "none");
		}
		else {
			this.div.style.setProperty("border-bottom", "2px solid white");
		}
	},
	to: function($column, $row)
	{
		var $top = 0, $left = 0;
		if($column >= 0 && $column <= this.maxColumn) {
			$left = this.width * $column;
		}
		if($row >= 0 && $row <= this.maxRow) {
			$top = this.height * $row;
		}
		this.div.style.setProperty("top", String($top)+"px");
		this.div.style.setProperty("left", String($left)+"px");
	},
};

