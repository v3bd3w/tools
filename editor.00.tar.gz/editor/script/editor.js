var editor = {
	textarea: null,
	charWidth: 10,
	charHeight: 20,
	offset: 55,
	init: function()
	{
		this.textarea = document.querySelector("textarea[name='editor']");
	},
	reflect: function($offset)
	{
		var $location = this.getLocation($offset);
		out($location);
		
	},
	getLocation: function($offset)
	{
		var $text = this.textarea.value;
		var $result = { 
			row: 0, 
			column: 0, 
		};
		if($offset < 0) {
			return($result);
		}
		var $row = 0;
		var $column = 0;
		var $index = 0;
		var $length = $text.length;
		while(true) {
			if($index >= $length) break;
			var $char = $text.charAt($index);
			if($char == "\n") {
				$result.row = $row;
				$row += 1;
				$result.column = $column;
				$column = 0;
			}
			else {
				$result.row = $row;
				$result.column = $column;
				$column += 1;
			}
			if($index >= $offset) break;
			$index += 1;
		}
		return($result);
	},
	scrollCorrection: function()
	{
		alert("$");
	},
	scrollToRow: function($row)
	{
	},
};

