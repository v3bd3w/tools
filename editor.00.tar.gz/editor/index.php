<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />

		<title>Editor</title>

		<link href="style/editor.css" rel="stylesheet" />
		<link href="style/cursor.css" rel="stylesheet" />
		<link href="style/main.css" rel="stylesheet" />
		<!-- <link href="" rel="stylesheet" /> -->
		<style>
body {
	background: grey;
}
		</style>

		<script src="script/editor.js"></script>
		<script src="script/cursor.js"></script>
		<script src="script/main.js"></script>
		<!-- <script src=""></script> -->
		<script>
		</script>
	</head>
	<body>
		<?php // require __DIR__.'/include/calibration.php'; ?>
		<?php require __DIR__.'/include/editor.php'; ?>
		<?php require __DIR__.'/include/cursor.php'; ?>
	</body>
</html>

