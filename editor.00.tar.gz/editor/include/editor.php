<textarea name="editor" disabled wrap="off"><?php
	$string = '';
	for($i = 0; $i < 1; $i += 1) {
		$string .= '0123456789';
	}
	$string .= "\n";
	for($i = 1; $i < 48; $i += 1) {
		$string .= "{$i}abcdefg\n";
	}
	echo($string);
?></textarea>
