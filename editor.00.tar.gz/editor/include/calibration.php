<div style="
	position: absolute;
	top: 0px;
	left: 0px;
	width: 530px;
	height: 100px;
	background: green;
	border: 1px solid yellow;
">font 10x20px </div>
<div style="
	position: absolute;
	top: 103px;
	left: 0px;
	width: 504px;
	height: 180px;
	background: grey;
	border: 1px solid red;
">button = 36px column = 14 raws = 5</div>

