<div name="codercursor"></div>
<div name="coderboard"><?php

$index = 0;
$string = "";

for($i = 0; $i < 5; $i += 1) {

	$string .= '<div name="coderlevel">';

	for($j = 0; $j < 0x10; $j += 1) {

		$string .= 
<<<HEREDOC
<div name="coderbutton" id="CB-{$index}"></div>
HEREDOC;
		$index += 1;
	}

	$string .= '</div>';
}

echo($string);

?></div>
